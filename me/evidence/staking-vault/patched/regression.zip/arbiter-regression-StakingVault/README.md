# ARBITER 回歸測試：Re‑entrancy in unstake() allows draining of other users’ stakes

這個資料夾是一個可以直接執行的 Foundry 專案。也可以只把 `test/arbiter/` 複製到你自己的專案。

用途：把這份測試放進你的專案，以後每次修改合約，都會自動再試一次同樣的攻擊，
並確認一般使用者在沒有攻擊時拿回的錢沒有變少。

## 裡面有什麼

| 檔案 | 內容 |
|---|---|
| `src/StakingVault.sol` | 稽核時的原合約（還沒修補） |
| `test/arbiter/ArbiterRegression.t.sol` | 當初證實成功的攻擊，加上回歸測試 `TestArbiterRegression` |
| `test/arbiter/Vm.sol` | 測試用到的 Foundry cheatcode 介面。不需要另外安裝 forge-std |
| `foundry.toml` | 編譯設定（solc 0.8.20） |

## 每個測試在檢查什麼

| 測試 | 檢查什麼 | 原合約 | 修好之後 |
|---|---|---|---|
| `testExploitBlocked` | 把當初成功的攻擊，在 4 種環境各重跑一次，攻擊必須失敗 | 失敗（代表攻擊還能成功） | 通過 |
| `testHonestPath0` | 環境 0（預設）：沒有攻擊時，使用者取回至少 1 ETH（原合約的金額） | 通過 | 通過 |
| `testHonestPath1` | 環境 1（受害者餘額 1000 倍）：沒有攻擊時，使用者取回至少 1 ETH（原合約的金額） | 通過 | 通過 |
| `testHonestPath2` | 環境 2（一週後）：沒有攻擊時，使用者取回至少 1 ETH（原合約的金額） | 通過 | 通過 |
| `testHonestPath3` | 環境 3（8 輪攻擊）：沒有攻擊時，使用者取回至少 1 ETH（原合約的金額） | 通過 | 通過 |

為什麼兩種都要：如果「修補」只是讓函式一律失敗（revert），攻擊當然也會失敗，
`testExploitBlocked` 就會通過；但一般使用者同樣拿不回錢，`testHonestPath` 會抓到這種假修補。

## 怎麼跑

在這個資料夾執行：

```bash
forge test
```

現在跑，會看到 `testExploitBlocked` 失敗、`testHonestPath*` 通過。這是正常的：原合約的漏洞還在。
把修補套用到 `src/StakingVault.sol` 之後再跑一次，應該全部通過。網頁下載的 `.patch` 檔可以這樣套用：

```bash
patch -p1 < 你下載的.patch
```

## 放進你自己的專案

1. 把 `test/arbiter/` 整個資料夾複製到你專案的 `test/` 底下。
2. 打開 `ArbiterRegression.t.sol`，把 `import "../../src/StakingVault.sol";` 改成你專案裡這份合約的位置（相對於這個測試檔）。
3. 只跑這組測試：`forge test --match-contract TestArbiterRegression`
4. 放進 CI，以後每次修改都會自動檢查。

## 要知道的限制

- 全部通過只代表：**這一個攻擊**在 4 種環境都失效，而且沒有攻擊時，使用者取回的錢沒有比原合約少。不代表合約沒有其他漏洞。
- 攻擊和使用者的操作步驟，是照當初證明攻擊時的寫法。如果你改了合約的對外介面（函式名稱、參數），這份測試要跟著改。
- 容差是 10 wei。

## 來源

- 漏洞：Re‑entrancy in unstake() allows draining of other users’ stakes（函式 `unstake()`）
- 證明方式：`victim_loss`。有攻擊時受害者取回的比沒有攻擊時少，而且攻擊者手上至少多了這個差額。
- 稽核模型：arbiter-gpt:latest；run：`web-20261122-170447-45f419`；產生時間：2026-11-22T17:10:05+0800
